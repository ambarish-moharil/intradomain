# INTRADOMAIN AMBIGUITY

DISAMBIGUATE INTRADOMAIN CONTEXTUAL AMBIGUITY

## Instructions

1. Install:

```
pip install intradomain_toolkit
```

2. Disambiguate a certain corpus:

```python

from intradomain_toolkit import disambiguation

# initialize context object (to disambiguate a corpus)
contextual = disambiguation.disambiguate()
