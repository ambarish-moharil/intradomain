"""
intradomain_toolkit

A context diambiguation library for natural language texts.
"""

__version__ = "0.1.0"
__author__ = 'Ambarish Moharil & Arpit Sharma'
__credits__ = 'Indian Institute of Science Education and Research, Bhopal'
